# Definir el color beige
BEIGE_COLOR = "#F5F5DC"

# Definir el estilo de botón unificado
BUTTON_STYLE = {
    "bg": "#4A90E2",
    "fg": "white",
    "font": ("Helvetica", 12),
    "relief": "raised",
    "bd": 2,
    "padx": 10,
    "pady": 5
}